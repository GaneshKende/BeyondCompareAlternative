-- External Game Name Preset for MID:101421 and CID:40300
USE Casino
GO


-- Updating Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo...
IF EXISTS(SELECT TOP 1 * FROM tb_InstalledClients WHERE ModuleID = 101421 AND ClientID = 40300)
    BEGIN
    IF NOT EXISTS (SELECT * FROM casino.tb_ExternalGameName WHERE ModuleID = 101421 AND ClientID = 40300)
        BEGIN
        
            INSERT INTO casino.tb_ExternalGameName SELECT 101421, 40300, 'MGS_candyCombo', 'MGS - Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo'
            PRINT('SUCCESSFULLY INSTALLED External Game Name for ''MGS - Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo''')
        END ELSE 
        BEGIN
            IF EXISTS (SELECT * FROM casino.tb_ExternalGameName WHERE ModuleID = 101421 and ClientID = 40300 AND ExternalSystemName <> 'MGS_candyCombo')
                BEGIN

                    
                    UPDATE casino.tb_ExternalGameName 
                    SET ExternalSystemName = 'MGS_candyCombo',
                    [Description] = 'MGS - Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo'
                    WHERE ModuleID = 101421 AND ClientID = 40300
                    PRINT('SUCCESSFULLY Updated External Game Name for MGS - Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo')
                END ELSE BEGIN
                    PRINT('External Game Name already exists!! For ModuleID 101421 and ClientID = 40300 ')
                END
        END 
END ELSE BEGIN
    PRINT('INFO! The Game with ModuleID 101421 and 40300 is not installed on this system.  Please ensure Presets have been run first.')
END
