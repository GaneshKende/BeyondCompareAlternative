-- External Game Name Preset for MID:101421 and CID:40300
USE Vanguard
GO

BEGIN TRAN


-- Updating Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo...
;WITH cte_ExternalGameName (ServerID, ModuleID, ClientID, ExternalSystemName, Description)
AS
(
  SELECT s.ServerID, 101421, 40300, 'MGS_candyCombo', 'MGS - Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo'
  FROM tb_Server s
  LEFT OUTER JOIN tb_ExternalSystemName e on e.ServerID = s.ServerID and e.ModuleID = 101421 and e.ClientID = 40300
  where e.ServerID is null
)
INSERT INTO tb_ExternalSystemName
SELECT e.ServerID, e.ModuleID, e.ClientID, e.ExternalSystemName, e.Description 
FROM cte_ExternalGameName e

COMMIT TRAN
