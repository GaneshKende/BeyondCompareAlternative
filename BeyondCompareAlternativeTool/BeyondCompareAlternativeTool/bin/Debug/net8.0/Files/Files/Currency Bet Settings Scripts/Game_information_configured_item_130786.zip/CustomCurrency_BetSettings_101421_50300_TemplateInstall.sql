-- This 32/64-bit script maps the currency bet settings in the Game Presets for ModuleID 101421 and ClientID 50300 to PSGI Currency Level.
USE Casino
GO

SET XACT_ABORT ON;
SET NOCOUNT ON

DECLARE @NL CHAR(1) = char(10);
DECLARE @MSG VARCHAR(MAX) = '';
DECLARE @ErrorMsg VARCHAR(MAX);
DECLARE @ErrorOccured BIT = 0;
DECLARE @Error INT;
DECLARE @RowCount INT;
DECLARE @RowId INT = 1;
DECLARE @NoOfCurrencies INT;


IF NOT EXISTS(SELECT 1 FROM dbo.tb_SystemSetting (NOLOCK)
        WHERE SystemSettingID = 56 AND SystemSettingIntValue = 1)
BEGIN
    RAISERROR ('CBS script cannot be executed in non quickfire Casino DBs',16,-1);
    RETURN;
END

IF NOT EXISTS (SELECT TOP 1 1 FROM dbo.tb_InstalledClients WHERE ModuleID = 101421 AND ClientID = 50300)
BEGIN
    RAISERROR ('Game is not installed', 16, -1);
	RETURN;
END

DECLARE @SettingsOverride TABLE (CurrencyID INT NOT NULL, TemplateID INT NOT NULL, SettingID INT NOT NULL)

DECLARE @SettingsTable TABLE (
	CurrencyId INT NOT NULL
	,TemplateID INT NOT NULL
	,SettingID INT
	,SettingIntValue BIGINT NULL
	,SettingStringValue VARCHAR(255) NULL
	,RowId INT
    ,UNIQUE NONCLUSTERED (CurrencyId, TemplateID, SettingID)
	);

DECLARE @ModuleCurrencyTemplate TABLE (CurrencyID INT NOT NULL, TemplateID INT NOT NULL);

DECLARE @OperatorId INT = -1;

INSERT INTO @SettingsOverride VALUES
	(29, 4, 106)
	,(29, 4, 108)
	,(29, 4, 178)
	,(29, 4, 215)
	,(29, 4, 291)


DECLARE @IsLvcsEnabled BIT = 0;
IF EXISTS (SELECT 1 FROM tb_SystemSetting WHERE SystemSettingID = 87 AND SystemSettingIntValue = 1)
BEGIN
    SET @IsLvcsEnabled = 1;
END;

IF @IsLvcsEnabled = 0
BEGIN
	INSERT INTO @ModuleCurrencyTemplate VALUES
	(3, 5)
	,(4, 7)
	,(7, 5)
	,(11, 5)
	,(13, 0)
	,(14, 5)
	,(19, 5)
	,(20, 4)
	,(23, 6)
	,(28, 6)
	,(29, 5)
	,(30, 6)
	,(31, 6)
	,(32, 14)
	,(33, 4)
	,(35, 14)
	,(36, 14)
	,(37, 6)
	,(41, 4)
	,(44, 7)
	,(45, 13)
	,(46, 14)
	,(47, 4)
	,(48, 4)
	,(49, 14)
	,(50, 14)
	,(51, 14)
	,(52, 14)
	,(53, 7)
	,(57, 14)
	,(58, 4)
	,(59, 14)
	,(60, 7)
	,(61, 14)
	,(62, 6)
	,(63, 6)
	,(64, 14)
	,(65, 5)
	,(67, 5)
	,(68, 4)
	,(71, 4)
	,(73, 6)
	,(74, 6)
	,(76, 4)
	,(77, 4)
	,(78, 7)
	,(79, 5)
	,(82, 14)
	,(83, 7)
	,(85, 14)
	,(93, 14)
	,(94, 7)
	,(101, 14)
	,(102, 6)
	,(103, 14)
	,(104, 5)
	,(109, 14)
	,(110, 0)
	,(111, 0)
	,(112, 0)
	,(113, 14)
	,(114, 6)
	,(138, 4)
	,(144, 7)
	,(163, 14)
	,(172, 14)
	,(177, 13)
	,(183, 5)
	,(251, 7);
END;
ELSE IF @IsLvcsEnabled = 1
BEGIN
	INSERT INTO @ModuleCurrencyTemplate VALUES
	(3, 5)
	,(4, 7)
	,(7, 5)
	,(11, 5)
	,(13, 0)
	,(14, 5)
	,(19, 5)
	,(20, 4)
	,(23, 6)
	,(28, 6)
	,(29, 5)
	,(30, 6)
	,(31, 6)
	,(32, 14)
	,(33, 4)
	,(35, 14)
	,(36, 8)
	,(37, 6)
	,(41, 4)
	,(44, 7)
	,(45, 13)
	,(46, 8)
	,(47, 4)
	,(48, 4)
	,(49, 10)
	,(50, 16)
	,(51, 14)
	,(52, 14)
	,(53, 7)
	,(57, 14)
	,(58, 4)
	,(59, 15)
	,(60, 7)
	,(61, 16)
	,(62, 6)
	,(63, 6)
	,(64, 14)
	,(65, 5)
	,(67, 5)
	,(68, 4)
	,(71, 4)
	,(73, 6)
	,(74, 6)
	,(76, 4)
	,(77, 4)
	,(78, 10)
	,(79, 5)
	,(82, 14)
	,(83, 7)
	,(85, 14)
	,(93, 17)
	,(94, 7)
	,(101, 14)
	,(102, 6)
	,(103, 10)
	,(104, 5)
	,(109, 8)
	,(110, 8)
	,(111, 8)
	,(112, 8)
	,(113, 8)
	,(114, 6)
	,(138, 4)
	,(144, 7)
	,(163, 14)
	,(172, 8)
	,(177, 13)
	,(183, 5)
	,(251, 7);
END;

SELECT @NoOfCurrencies = COUNT(1) FROM @ModuleCurrencyTemplate;

-- Collect Preset Settings ---
INSERT INTO @SettingsTable (
		CurrencyID
       ,TemplateID 
       ,SettingID
       ,SettingIntValue
       ,SettingStringValue)
SELECT MCT.CurrencyID
       ,MCT.TemplateID 
       ,stv.SettingID
       ,stv.SettingIntValue
       ,stv.SettingStringValue
FROM  (SELECT 101421 AS ModuleID, 50300 AS ClientID, * FROM  @ModuleCurrencyTemplate) MCT
LEFT JOIN dbo.tb_SettingTemplateValue AS stv ON MCT.TemplateID = STV.TemplateID
AND MCT.ModuleID = STV.ModuleID AND MCT.ClientID = STV.ClientID;

IF EXISTS (SELECT TOP 1 1  FROM @SettingsTable WHERE SettingId IS NULL) 
BEGIN
     SELECT  @ErrorMsg = STUFF((SELECT ',' +CAST(ST.CurrencyId AS NVARCHAR(255)) FROM @SettingsTable ST where SettingId IS NULL for xml path('')),1,1,'');
     SET @ErrorMsg = N'WARN: The below currency(s) will not be installed as the settings are missing on casino. (Try running the latest preset and then run this script again):-' + @NL + @ErrorMsg;

     RAISERROR (@ErrorMsg, 15, 1);
     SET @ErrorOccured = 1;

     DELETE FROM @SettingsTable WHERE SettingId IS NULL;
END

IF  EXISTS (
        SELECT 1
        FROM @SettingsTable ST
        left JOIN dbo.tb_DefaultModuleSetting DMS with (readuncommitted) 
        ON ST.SettingID = DMS.SettingID 
        AND dms.OperatorId = @OperatorId
        AND DMS.ModuleID = 101421
		AND DMS.ClientID = 50300
        where DMS.SettingId is null
        )
BEGIN
    RAISERROR ('MISSING SETTINGS IN tb_DefaultModuleSetting, Re-Install PRESETS WITH FORCEUPDATE = 1. To FIX THIS ISSUE.', 16,- 1);
	RETURN;
END
	

BEGIN TRY
	--Updating the overrides
	UPDATE ST 
	SET SettingIntValue = stv.SettingIntValue, SettingStringValue = stv.SettingStringValue
	FROM @SettingsTable ST
	INNER JOIN @SettingsOverride SO ON ST.CurrencyId=SO.CurrencyID AND ST.SettingID=SO.SettingID
	INNER JOIN tb_SettingTemplateValue STV ON SO.TemplateID = STV.TemplateID
		AND SO.SettingID = STV.SettingID
	WHERE stv.ModuleID =101421 AND STV.ClientID = 50300;

	--Delete the values from looping table which are already there in tb_CurrencyModuleSetting to reduce number of iterations
	DELETE ST
	FROM @SettingsTable ST
	WHERE exists (SELECT * from dbo.tb_CurrencyModuleSetting CMS WITH (readuncommitted) 
	WHERE CMS.OperatorId = @OperatorId and CMS.CurrencyID = st.CurrencyId and CMS.ModuleID = 101421 and CMS.ClientID = 50300 and CMS.SettingID = st.SettingID
	AND (ISNULL(CMS.SettingIntValue, 0) = ISNULL(ST.SettingIntValue, 0) AND ISNULL(CMS.SettingStringValue, '') = ISNULL(ST.SettingStringValue, '')));

	--Update the RowId values (to be used in looping logic)  
	UPDATE ST 
	SET ST.RowId= ST.row_num 
	FROM (SELECT RowId, ROW_NUMBER() OVER (ORDER BY CurrencyId) row_num  from @SettingsTable) ST;

END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;

	SET @MSG = CONCAT ('An error occured. ErrorNumber: ' ,ERROR_NUMBER() 
		,'ErrorSeverity: ' ,ERROR_SEVERITY()
		,'ErrorState: ' ,ERROR_STATE()
		,'ErrorProcedure: ' ,ERROR_PROCEDURE()
		,'ErrorLine: ' ,ERROR_LINE()
		,'ErrorMessage: ' ,ERROR_MESSAGE()
			,' ,Error Updating Custom Bet settings '
			);
				
	RAISERROR (
			@MSG
			,16
			,- 1
			);

			RETURN;
END CATCH;

--Looping through the values need update/insert and commit them PER CURRENCY basis
--It will rollback all the setings for a currency if any of the setting fails to update, and CONTINUE WITH THE NEXT CURRENCY 
--Since pr_UpdateCurrencyModuleSetting old-school error handling, 
--we are keeping this outside try...catch to honor their error handling

DECLARE @LastCurrencyId INT, @CurrencyId INT, @SettingID INT, @SettingIntValue BIGINT, @SettingStringValue VARCHAR(255);
DECLARE @TotalRowsCommitted INT = 0;
DECLARE @TotalRowsCommittedInCurrentTans INT = 0;
DECLARE @FailedCurrencyId INT = -1; --To keep track which currency failed
DECLARE @NoOfCurrenciesNeedUpdate INT;
DECLARE @ModuleExcludedInDb BIT = 0;
DECLARE @ExcludeModule BIT = 0; -- Depends upon ExcludeModule flag in Game info
DECLARE @CommittedCurrenciesCount INT;

SELECT @RowCount = COUNT(*) FROM @SettingsTable;
IF @RowCount = 0
BEGIN
	PRINT 'Settings are already upto date!';
	RETURN;
END

SELECT @NoOfCurrenciesNeedUpdate = COUNT(DISTINCT CurrencyId) FROM @SettingsTable;
SET @CommittedCurrenciesCount = @NoOfCurrenciesNeedUpdate;

--Remove ModuleId from Exclusion list
IF EXISTS (SELECT TOP 1 1 FROM DBO.tb_ExcludeModule WHERE ModuleID = 101421)
BEGIN
	RAISERROR (N'Warning: Updating settings for a game variant (ModuleId 101421, ClientId 50300) whose ModuleId is in tb_ExcludeModule', 10, 1);
	SET @ModuleExcludedInDb = 1;
END

SET @LastCurrencyId = -1; --To keep track which currency to commit next

BEGIN TRANSACTION
WHILE @RowId <= @RowCount
BEGIN
	SELECT @CurrencyID = CurrencyID, @SettingID = SettingID, @SettingIntValue = SettingIntValue, @SettingStringValue = SettingStringValue FROM @SettingsTable 
	WHERE RowId = @RowId;

	IF @LastCurrencyId = -1 SET @LastCurrencyId = @CurrencyId; --Executes only once in the first iteration of the loop

	--This block takes care that Transaction is committed per currency
	IF @LastCurrencyId <> @CurrencyId --Commit the current transaction and start a new transaction
	BEGIN
		IF @@TRANCOUNT > 0 
		BEGIN
			COMMIT TRANSACTION;
			SET @TotalRowsCommitted = @TotalRowsCommitted + @TotalRowsCommittedInCurrentTans;
			SET @TotalRowsCommittedInCurrentTans = 0;
			SET @MSG = @MSG + @NL + FORMATMESSAGE('Settings for CurrencyId: %d Committed successfully', @LastCurrencyId);
			BEGIN TRANSACTION;
		END
		ELSE
		BEGIN
			BEGIN TRANSACTION;
		END
		
		SET @FailedCurrencyId = -1; --reset the Failed Currency tracker
		SET @LastCurrencyId = @CurrencyId;
	END
	
	--This block takes care that Transaction is rolled back if any of the setting for current currency fails
	-- and continues with the next currency
	IF @FailedCurrencyId = -1 --no setting for this Currency failed so far
	BEGIN
		IF @ModuleExcludedInDb = 1
		BEGIN
			DELETE FROM tb_ExcludeModule WHERE ModuleID = 101421;
			SET @ModuleExcludedInDb = 0;
		END;

		EXEC pr_UpdateCurrencyModuleSetting @CurrencyID = @CurrencyID, @ModuleID = 101421, @ClientID = 50300, @SettingID = @SettingID, @SettingIntValue = @SettingIntValue, @SettingStringValue = @SettingStringValue

		SET @Error = @@ERROR;

		IF @ExcludeModule = 1 --if ExcludeModule flag is set to true for the game in Game info
		BEGIN
			INSERT INTO tb_ExcludeModule (ModuleID) VALUES(101421);
			SET @ModuleExcludedInDb = 1;
		END;

		IF (@Error <> 0)
		BEGIN
			SET @FailedCurrencyId = @CurrencyId; --Remember the CurrencyId that failed to update
			SET @TotalRowsCommittedInCurrentTans = 0;
			IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
			RAISERROR('%sFailed updating currency module setting for Currency: %i and Setting: %i. Rolling back Currency: %i', 16, -1, @NL, @CurrencyID, @SettingID, @CurrencyID);
			SET @ErrorOccured = 1;
			SET @CommittedCurrenciesCount = @CommittedCurrenciesCount - 1;
		END
		ELSE
		BEGIN
			SET @TotalRowsCommittedInCurrentTans = @TotalRowsCommittedInCurrentTans + 1;
		END
	END

	SET @RowId = @RowId + 1;
END

IF @@TRANCOUNT > 0 
BEGIN
	COMMIT TRANSACTION;
	SET @TotalRowsCommitted = @TotalRowsCommitted + @TotalRowsCommittedInCurrentTans;
	IF @LastCurrencyId > -1 
	BEGIN
		SET @MSG = @MSG + @NL + FORMATMESSAGE('Settings for CurrencyId: %d Committed successfully', @LastCurrencyId);
		SET @MSG = @MSG + @NL + 'INFO:	Currency Settings Installed';
	END
END

SET @MSG = @MSG + @NL + @NL + FORMATMESSAGE('Total number of Currency(s): %d', @NoOfCurrencies);
SET @MSG = @MSG + @NL + FORMATMESSAGE('Currency(s) updated: %d', @CommittedCurrenciesCount);
SET @MSG = @MSG + @NL + FORMATMESSAGE('Currency(s) failed: %d', @NoOfCurrenciesNeedUpdate - @CommittedCurrenciesCount);
SET @MSG = @MSG + @NL + FORMATMESSAGE('Currency(s) already upto date: %d', @NoOfCurrencies - @NoOfCurrenciesNeedUpdate);

IF @ErrorOccured = 0
BEGIN
	SET @MSG = @MSG + @NL + 'Execution completed!'
	PRINT @MSG
END
ELSE
BEGIN
	SET @ErrorMsg = @NL + '!!! Query completed with Error !!!';
	RAISERROR (@ErrorMsg, 15, 1);

	SET @MSG = @MSG + @NL + @NL + '!!! Query completed with Error !!!';
	PRINT @MSG;
END
