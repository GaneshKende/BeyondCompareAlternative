-- This 32/64-bit script is used to populate free game offers based on the Game Information.
USE CASINO
GO

-- The following game is being generated:
  -- 101421, 40300 (Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo)
begin tran

set nocount on

declare @BettingModelID int
declare @CostResult bigint
declare @OfferID int
declare @CurrentOfferCost bigint
declare @OperatorIDCheck int = dbo.fn_GetOperatorIDForSQLUser();
declare @ChipSizes varchar(1000)

declare @IsLvcsEnabled bit = 0
if exists (select 1 from tb_SystemSetting where SystemSettingID = 87 AND SystemSettingIntValue = 1)
begin
    set @IsLvcsEnabled = 1
end

if @IsLvcsEnabled = 0
begin
	set @ChipSizes = '1,2,5,10,20,25,50,100,200,500,1000,2000,2500,5000,10000'
end
else
begin
	set @ChipSizes = '1,2,5,10,20,25,50,100,200,500,1000,2000,2500,5000,10000,20000,50000,100000,200000,500000,1000000,2000000,5000000,10000000,20000000,50000000'
end

update tb_Slot_ValidBetLimits set ChipSizes = @ChipSizes where ChipSizes <> @ChipSizes and ModuleID = 101421 
 
select @CurrentOfferCost = dbo.fn_CalculateSlotFreeGameCost(101421,10,1,1)

if not exists (select top 1 * from tb_BettingModel where ModuleID = 101421 and ClientID = 40300 and Cost = @CurrentOfferCost and OperatorID =  @OperatorIDCheck)
begin
-- create the freegame offer game betting model for Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo at DEF currency profile

exec dbo.pr_AddSlotbettingModel @Name = N'SlingshotHTML5SlotCandyCombo™PowerComboDEF', @ModuleID = 101421, @ClientID = 40300, @NumberLines = 20, @ChipSize = 1, @NrCoins = 1, @BettingModelID = @BettingModelID output, @Cost = null, @SideBet = null

    if @@error <> 0
    begin
      rollback tran
      raiserror('Error executing pr_AddSlotBettingModel', 16, -1)
      return
    end

    print 'Free Game Bet Model ''SlingshotHTML5SlotCandyCombo™PowerComboDEF'' was successfully created.'
end else
begin
    set @BettingModelID = (select top 1 BettingModelID from tb_BettingModel where ModuleID = 101421 and ClientID = 40300 and Cost = @CurrentOfferCost and OperatorID =  @OperatorIDCheck)
end
if not exists(select top 1 * from tb_FreeGameOffer where [Description] = 'CandyCombo™PowerComboDEF' and NrgamesToAward = 10 and CreditTypeID = 0 and OperatorID =  @OperatorIDCheck)
    begin
-- create the free game betting offer
        exec dbo.pr_AddFreeGameOffer @Description = N'CandyCombo™PowerComboDEF', @DisplayLine1 = N' ', @DisplayLine2 = NULL, 
        @NrGamesToAward = 10, @CreditTypeId = 0, @StartDate = '2025-02-11T00:00:00', @EndDate = '2045-02-11T00:00:00', @IsCurrencyLevelled = 1,
        @Duration = 1, @DurationTypeID = 3, @IsMGSOffer = 0, @OfferID = @OfferID output, @FreeGameOfferGUID = 'ab15b673-1e1d-4287-a7aa-8cf9cd6cd38e'
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOffer', 16, -1)
            return
        end
        
        print ('Free game offer ''CandyCombo™PowerComboDEF'' was sucessfully created.')
        
        -- map the offer to the bet model
        exec dbo.pr_AddFreeGameOfferToGameMap @OfferId = @OfferID, @BettingModelID = @BettingModelID
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOfferToGameMap', 16, -1)
            return
        end
    end else 
    begin
        (select @OfferID = OfferID from tb_FreeGameOffer where [Description] = 'CandyCombo™PowerComboDEF' and NrGamesToAward = 10 and CreditTypeID = 0 and OperatorID =  @OperatorIDCheck)
        -- map this existing offer to the BettingModel
        if not exists(select top 1 * from tb_FreeGameOfferTogameMap where OfferID = @OfferID and BettingModelID = @BettingModelID)
        begin
            exec dbo.pr_AddFreeGameOfferToGamemap @OfferID = @OfferID, @BettingModelID = @BettingModelID
            
            if @@error <> 0
            begin
                rollback tran
                raiserror('Error executing pr_AddFreeGameOffeToGameMap', 16, -1)
                return
            end
            print ('Free Game Offer ''CandyCombo™PowerComboDEF'' was successfully mapped to BettingModel ''SlingshotHTML5SlotCandyCombo™PowerComboDEF''')     
        end
    end
if not exists(select top 1 * from tb_FreeGameOffer where [Description] = 'CandyCombo™PowerComboBonusDEF' and NrgamesToAward = 10 and CreditTypeID = 1 and OperatorID =  @OperatorIDCheck)
    begin
-- create the free game betting offer
        exec dbo.pr_AddFreeGameOffer @Description = N'CandyCombo™PowerComboBonusDEF', @DisplayLine1 = N' ', @DisplayLine2 = NULL, 
        @NrGamesToAward = 10, @CreditTypeId = 1, @StartDate = '2025-02-11T00:00:00', @EndDate = '2045-02-11T00:00:00', @IsCurrencyLevelled = 1,
        @Duration = 1, @DurationTypeID = 3, @IsMGSOffer = 0, @OfferID = @OfferID output, @FreeGameOfferGUID = '5e3d81d6-2ec2-4c29-8274-c888dbd3eaa8'
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOffer', 16, -1)
            return
        end
        
        print ('Free game offer ''CandyCombo™PowerComboBonusDEF'' was sucessfully created.')
        
        -- map the offer to the bet model
        exec dbo.pr_AddFreeGameOfferToGameMap @OfferId = @OfferID, @BettingModelID = @BettingModelID
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOfferToGameMap', 16, -1)
            return
        end
    end else 
    begin
        (select @OfferID = OfferID from tb_FreeGameOffer where [Description] = 'CandyCombo™PowerComboBonusDEF' and NrGamesToAward = 10 and CreditTypeID = 1 and OperatorID =  @OperatorIDCheck)
        -- map this existing offer to the BettingModel
        if not exists(select top 1 * from tb_FreeGameOfferTogameMap where OfferID = @OfferID and BettingModelID = @BettingModelID)
        begin
            exec dbo.pr_AddFreeGameOfferToGamemap @OfferID = @OfferID, @BettingModelID = @BettingModelID
            
            if @@error <> 0
            begin
                rollback tran
                raiserror('Error executing pr_AddFreeGameOffeToGameMap', 16, -1)
                return
            end
            print ('Free Game Offer ''CandyCombo™PowerComboBonusDEF'' was successfully mapped to BettingModel ''SlingshotHTML5SlotCandyCombo™PowerComboDEF''')     
        end
    end
if not exists(select top 1 * from tb_FreeGameOffer where [Description] = '25CandyCombo™PowerComboDEF' and NrgamesToAward = 25 and CreditTypeID = 0 and OperatorID =  @OperatorIDCheck)
    begin
-- create the free game betting offer
        exec dbo.pr_AddFreeGameOffer @Description = N'25CandyCombo™PowerComboDEF', @DisplayLine1 = N' ', @DisplayLine2 = NULL, 
        @NrGamesToAward = 25, @CreditTypeId = 0, @StartDate = '2025-02-11T00:00:00', @EndDate = '2045-02-11T00:00:00', @IsCurrencyLevelled = 1,
        @Duration = 1, @DurationTypeID = 3, @IsMGSOffer = 0, @OfferID = @OfferID output, @FreeGameOfferGUID = 'cfb09d61-9936-4837-8edf-0c9a5211afda'
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOffer', 16, -1)
            return
        end
        
        print ('Free game offer ''25CandyCombo™PowerComboDEF'' was sucessfully created.')
        
        -- map the offer to the bet model
        exec dbo.pr_AddFreeGameOfferToGameMap @OfferId = @OfferID, @BettingModelID = @BettingModelID
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOfferToGameMap', 16, -1)
            return
        end
    end else 
    begin
        (select @OfferID = OfferID from tb_FreeGameOffer where [Description] = '25CandyCombo™PowerComboDEF' and NrGamesToAward = 25 and CreditTypeID = 0 and OperatorID =  @OperatorIDCheck)
        -- map this existing offer to the BettingModel
        if not exists(select top 1 * from tb_FreeGameOfferTogameMap where OfferID = @OfferID and BettingModelID = @BettingModelID)
        begin
            exec dbo.pr_AddFreeGameOfferToGamemap @OfferID = @OfferID, @BettingModelID = @BettingModelID
            
            if @@error <> 0
            begin
                rollback tran
                raiserror('Error executing pr_AddFreeGameOffeToGameMap', 16, -1)
                return
            end
            print ('Free Game Offer ''25CandyCombo™PowerComboDEF'' was successfully mapped to BettingModel ''SlingshotHTML5SlotCandyCombo™PowerComboDEF''')     
        end
    end
if not exists(select top 1 * from tb_FreeGameOffer where [Description] = '25CandyCombo™PowerComboBonusDEF' and NrgamesToAward = 25 and CreditTypeID = 1 and OperatorID =  @OperatorIDCheck)
    begin
-- create the free game betting offer
        exec dbo.pr_AddFreeGameOffer @Description = N'25CandyCombo™PowerComboBonusDEF', @DisplayLine1 = N' ', @DisplayLine2 = NULL, 
        @NrGamesToAward = 25, @CreditTypeId = 1, @StartDate = '2025-02-11T00:00:00', @EndDate = '2045-02-11T00:00:00', @IsCurrencyLevelled = 1,
        @Duration = 1, @DurationTypeID = 3, @IsMGSOffer = 0, @OfferID = @OfferID output, @FreeGameOfferGUID = '04354d43-25b9-490d-8ef4-960d11e751d2'
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOffer', 16, -1)
            return
        end
        
        print ('Free game offer ''25CandyCombo™PowerComboBonusDEF'' was sucessfully created.')
        
        -- map the offer to the bet model
        exec dbo.pr_AddFreeGameOfferToGameMap @OfferId = @OfferID, @BettingModelID = @BettingModelID
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOfferToGameMap', 16, -1)
            return
        end
    end else 
    begin
        (select @OfferID = OfferID from tb_FreeGameOffer where [Description] = '25CandyCombo™PowerComboBonusDEF' and NrGamesToAward = 25 and CreditTypeID = 1 and OperatorID =  @OperatorIDCheck)
        -- map this existing offer to the BettingModel
        if not exists(select top 1 * from tb_FreeGameOfferTogameMap where OfferID = @OfferID and BettingModelID = @BettingModelID)
        begin
            exec dbo.pr_AddFreeGameOfferToGamemap @OfferID = @OfferID, @BettingModelID = @BettingModelID
            
            if @@error <> 0
            begin
                rollback tran
                raiserror('Error executing pr_AddFreeGameOffeToGameMap', 16, -1)
                return
            end
            print ('Free Game Offer ''25CandyCombo™PowerComboBonusDEF'' was successfully mapped to BettingModel ''SlingshotHTML5SlotCandyCombo™PowerComboDEF''')     
        end
    end
if not exists(select top 1 * from tb_FreeGameOffer where [Description] = '50CandyCombo™PowerComboDEF' and NrgamesToAward = 50 and CreditTypeID = 0 and OperatorID =  @OperatorIDCheck)
    begin
-- create the free game betting offer
        exec dbo.pr_AddFreeGameOffer @Description = N'50CandyCombo™PowerComboDEF', @DisplayLine1 = N' ', @DisplayLine2 = NULL, 
        @NrGamesToAward = 50, @CreditTypeId = 0, @StartDate = '2025-02-11T00:00:00', @EndDate = '2045-02-11T00:00:00', @IsCurrencyLevelled = 1,
        @Duration = 1, @DurationTypeID = 3, @IsMGSOffer = 0, @OfferID = @OfferID output, @FreeGameOfferGUID = 'a6c8c424-77a6-4561-ab92-04769c7f9f21'
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOffer', 16, -1)
            return
        end
        
        print ('Free game offer ''50CandyCombo™PowerComboDEF'' was sucessfully created.')
        
        -- map the offer to the bet model
        exec dbo.pr_AddFreeGameOfferToGameMap @OfferId = @OfferID, @BettingModelID = @BettingModelID
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOfferToGameMap', 16, -1)
            return
        end
    end else 
    begin
        (select @OfferID = OfferID from tb_FreeGameOffer where [Description] = '50CandyCombo™PowerComboDEF' and NrGamesToAward = 50 and CreditTypeID = 0 and OperatorID =  @OperatorIDCheck)
        -- map this existing offer to the BettingModel
        if not exists(select top 1 * from tb_FreeGameOfferTogameMap where OfferID = @OfferID and BettingModelID = @BettingModelID)
        begin
            exec dbo.pr_AddFreeGameOfferToGamemap @OfferID = @OfferID, @BettingModelID = @BettingModelID
            
            if @@error <> 0
            begin
                rollback tran
                raiserror('Error executing pr_AddFreeGameOffeToGameMap', 16, -1)
                return
            end
            print ('Free Game Offer ''50CandyCombo™PowerComboDEF'' was successfully mapped to BettingModel ''SlingshotHTML5SlotCandyCombo™PowerComboDEF''')     
        end
    end
if not exists(select top 1 * from tb_FreeGameOffer where [Description] = '50CandyCombo™PowerComboBonusDEF' and NrgamesToAward = 50 and CreditTypeID = 1 and OperatorID =  @OperatorIDCheck)
    begin
-- create the free game betting offer
        exec dbo.pr_AddFreeGameOffer @Description = N'50CandyCombo™PowerComboBonusDEF', @DisplayLine1 = N' ', @DisplayLine2 = NULL, 
        @NrGamesToAward = 50, @CreditTypeId = 1, @StartDate = '2025-02-11T00:00:00', @EndDate = '2045-02-11T00:00:00', @IsCurrencyLevelled = 1,
        @Duration = 1, @DurationTypeID = 3, @IsMGSOffer = 0, @OfferID = @OfferID output, @FreeGameOfferGUID = 'b912f20a-23ee-411b-84fa-9af1cfb49fcd'
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOffer', 16, -1)
            return
        end
        
        print ('Free game offer ''50CandyCombo™PowerComboBonusDEF'' was sucessfully created.')
        
        -- map the offer to the bet model
        exec dbo.pr_AddFreeGameOfferToGameMap @OfferId = @OfferID, @BettingModelID = @BettingModelID
        
        if @@error <> 0
        begin
            rollback tran
            raiserror('Error executing pr_AddFreeGameOfferToGameMap', 16, -1)
            return
        end
    end else 
    begin
        (select @OfferID = OfferID from tb_FreeGameOffer where [Description] = '50CandyCombo™PowerComboBonusDEF' and NrGamesToAward = 50 and CreditTypeID = 1 and OperatorID =  @OperatorIDCheck)
        -- map this existing offer to the BettingModel
        if not exists(select top 1 * from tb_FreeGameOfferTogameMap where OfferID = @OfferID and BettingModelID = @BettingModelID)
        begin
            exec dbo.pr_AddFreeGameOfferToGamemap @OfferID = @OfferID, @BettingModelID = @BettingModelID
            
            if @@error <> 0
            begin
                rollback tran
                raiserror('Error executing pr_AddFreeGameOffeToGameMap', 16, -1)
                return
            end
            print ('Free Game Offer ''50CandyCombo™PowerComboBonusDEF'' was successfully mapped to BettingModel ''SlingshotHTML5SlotCandyCombo™PowerComboDEF''')     
        end
    end
commit tran
