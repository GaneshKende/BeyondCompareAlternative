USE CASINO
GO
SET NOCOUNT ON
--------------------------------------------------------------------------------------------
--Region Create tb_Module Information
--------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT 1 from tb_Module WHERE ModuleID =101421 AND ModuleName = 'Candy Combo™ - Power Combo' and ModuleIP = '')
BEGIN
    RAISERROR(N'ERROR: Could not find a record in tb_Module  for ModuleID= 101421 AND ModuleName=Candy Combo™ - Power Combo  and ModuleIP=''', 15, 1)
    RETURN;
END
--------------------------------------------------------------------------------------------
        --End tb_Module Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Region Create tb_ModuleTheoretical Information
--------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT 1 FROM dbo.tb_ModuleTheoretical WHERE ModuleID = 101421 AND Theoretical IS NOT NULL)
BEGIN
    RAISERROR(N'ERROR: Cound not find a record in tb_ModuleTheoretical for ModuleID=101421 with payout information.', 15, 1)
    RETURN;
END
--------------------------------------------------------------------------------------------
--End tb_ModuleTheoretical Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Region Update Game Categories(Game Archiving and Grouping according to revenue stream)
--------------------------------------------------------------------------------------------
    DECLARE @GameGroupTypeID INT,
            @GameGroupID INT;

SELECT @GameGroupTypeID = GameGroupTypeID FROM tb_GameGroupType WHERE Description ='MGS Archiving Groups'
IF(@@ROWCOUNT <> 1)
    BEGIN
        RAISERROR(N'ERROR: tb_GameGroupType does not contain a row for Description: ''MGS Archiving Groups''', 15, 1)
        RETURN;
    END;
ELSE 
    BEGIN
        PRINT N'OK: tb_GameGroupType ''MGS Archiving Groups'' exists'
    END

SELECT @GameGroupID = GameGroupID FROM tb_GameGroup WHERE Description ='Extensible Game' AND GameGroupTypeID = @GameGroupTypeID
IF(@@ROWCOUNT <> 1)
    BEGIN
        RAISERROR(N'ERROR: tb_GameGroup does not contain a row for Description ''Extensible Game''', 15, 1)
        RETURN;
    END;
    ELSE 
    BEGIN
        PRINT N'OK: tb_GameGroup ''Extensible Game''  exists'
    END;

DECLARE @GameArchivingGroupDescription nvarchar(50)
SET @GameArchivingGroupDescription = 'MGS Archiving Groups'
DECLARE @GameArchivingGroupID int
SET @GameArchivingGroupID = @GameGroupID

IF NOT EXISTS(SELECT GameGroupID FROM tb_BasicGameGroup WHERE GameGroupID = @GameGroupID)
    BEGIN
        RAISERROR(N'ERROR: tb_BasicGameGroup does not contain a row for GameGroupID %d', 15, 1, @GameGroupID)
        RETURN;
    END;
ELSE 
    BEGIN
        PRINT N'OK: tb_BasicGameGroup GameGroupID ' + cast(@GameGroupID as varchar(5)) +' exists'
    END

IF NOT EXISTS(SELECT GameGroupID FROM tb_BasicGameGroupMember WHERE GameGroupID = @GameGroupID AND ModuleID = 101421)
    BEGIN
        RAISERROR(N'ERROR: tb_BasicGameGroupMember does not contain a row for GameGroupID %d ModuleID 101421', 15, 1, @GameGroupID)
        RETURN;
    END;
ELSE 
    BEGIN
        PRINT N'OK: tb_BasicGameGroupMember GameGroupID ' 
    + cast(@GameGroupID as varchar(5)) +' and ModuleID 101421 exists'
    END

SELECT @GameGroupTypeID = GameGroupTypeID FROM tb_GameGroupType WHERE Description ='Game Category'
IF(@@ROWCOUNT <> 1)
    BEGIN
        RAISERROR(N'ERROR: tb_GameGroupType does not contain a row for Description: ''Game Category''', 15, 1)
        RETURN;
    END;
ELSE 
    BEGIN
        PRINT N'OK: tb_GameGroupType ''Game Category'' exists'
    END

SELECT @GameGroupID = GameGroupID FROM tb_GameGroup WHERE Description ='Slots' AND GameGroupTypeID = @GameGroupTypeID
IF(@@ROWCOUNT <> 1)
    BEGIN
        RAISERROR(N'ERROR: tb_GameGroup does not contain a row for Description ''Slots''', 15, 1)
        RETURN;
    END;
    ELSE 
    BEGIN
        PRINT N'OK: tb_GameGroup ''Slots''  exists'
    END;


IF NOT EXISTS(SELECT GameGroupID FROM tb_BasicGameGroup WHERE GameGroupID = @GameGroupID)
    BEGIN
        RAISERROR(N'ERROR: tb_BasicGameGroup does not contain a row for GameGroupID %d', 15, 1, @GameGroupID)
        RETURN;
    END;
ELSE 
    BEGIN
        PRINT N'OK: tb_BasicGameGroup GameGroupID ' + cast(@GameGroupID as varchar(5)) +' exists'
    END

IF NOT EXISTS(SELECT GameGroupID FROM tb_BasicGameGroupMember WHERE GameGroupID = @GameGroupID AND ModuleID = 101421)
    BEGIN
        RAISERROR(N'ERROR: tb_BasicGameGroupMember does not contain a row for GameGroupID %d ModuleID 101421', 15, 1, @GameGroupID)
        RETURN;
    END;
ELSE 
    BEGIN
        PRINT N'OK: tb_BasicGameGroupMember GameGroupID ' 
    + cast(@GameGroupID as varchar(5)) +' and ModuleID 101421 exists'
    END

SELECT @GameGroupTypeID = GameGroupTypeID FROM tb_GameGroupType WHERE Description ='Free Game Betting Model'
IF(@@ROWCOUNT <> 1)
    BEGIN
        RAISERROR(N'ERROR: tb_GameGroupType does not contain a row for Description: ''Free Game Betting Model''', 15, 1)
        RETURN;
    END;
ELSE 
    BEGIN
        PRINT N'OK: tb_GameGroupType ''Free Game Betting Model'' exists'
    END

SELECT @GameGroupID = GameGroupID FROM tb_GameGroup WHERE Description ='Slot' AND GameGroupTypeID = @GameGroupTypeID
IF(@@ROWCOUNT <> 1)
    BEGIN
        RAISERROR(N'ERROR: tb_GameGroup does not contain a row for Description ''Slot''', 15, 1)
        RETURN;
    END;
    ELSE 
    BEGIN
        PRINT N'OK: tb_GameGroup ''Slot''  exists'
    END;


IF NOT EXISTS(SELECT GameGroupID FROM tb_BasicGameGroup WHERE GameGroupID = @GameGroupID)
    BEGIN
        RAISERROR(N'ERROR: tb_BasicGameGroup does not contain a row for GameGroupID %d', 15, 1, @GameGroupID)
        RETURN;
    END;
ELSE 
    BEGIN
        PRINT N'OK: tb_BasicGameGroup GameGroupID ' + cast(@GameGroupID as varchar(5)) +' exists'
    END

IF NOT EXISTS(SELECT GameGroupID FROM tb_BasicGameGroupMember WHERE GameGroupID = @GameGroupID AND ModuleID = 101421)
    BEGIN
        RAISERROR(N'ERROR: tb_BasicGameGroupMember does not contain a row for GameGroupID %d ModuleID 101421', 15, 1, @GameGroupID)
        RETURN;
    END;
ELSE 
    BEGIN
        PRINT N'OK: tb_BasicGameGroupMember GameGroupID ' 
    + cast(@GameGroupID as varchar(5)) +' and ModuleID 101421 exists'
    END
--------------------------------------------------------------------------------------------
----End tb_BasicGameGroupMember Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Region Update Default Language Game Name(Friendly Game Name)
--------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT 1 FROM tb_InstalledClients ic
        INNER JOIN tb_TranslatedString ts on ic.TranslationContextID = ts.TranslationContextID
        AND ic.TranslationStringID = ts.TranslationStringID
        WHERE ic.ModuleID = 101421 AND ic.ClientID = 40300 AND ts.LanguageID =1 AND ts.TranslatedString = N'Candy Combo™ - Power Combo')
    BEGIN
        RAISERROR(N'ERROR: Translation String ''Candy Combo™ - Power Combo'' with Language ID: 1 does not exist for MID: 101421 and CID: 40300', 16, -1)
        RETURN;
    END;
    ELSE 
    BEGIN
        PRINT N'OK: Translation string ''Candy Combo™ - Power Combo'' for language ID 1 exists for MID: 101421 and CID:40300'
    END
--------------------------------------------------------------------------------------------
--End tb_InstalledClients Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Update Common Game Settings
--------------------------------------------------------------------------------------------
DECLARE @TheIntValue BIGINT,@TheStrValue VARCHAR(255); 
    IF (SELECT Count(*) FROM tb_GameSettings  WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'HasBonusFeature') = 0
    BEGIN
        RAISERROR(N'ERROR: GameSetting HasBonusFeature not found.', 15, 1);
        RETURN;
    END;
    ELSE 
    BEGIN
        SET @TheIntValue = NULL
        SET @TheStrValue = NULL
                SELECT @TheIntValue = IntValue, @TheStrValue = StrValue FROM tb_GameSettings WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'HasBonusFeature'
                  IF NOT @TheStrValue IS NULL
                   BEGIN
                      RAISERROR(N'ERROR: String value for HasBonusFeature should not be set but it has value %s', 15, 1, @TheStrValue)
                      RETURN
                   END;
                  ELSE 
                   BEGIN
                      IF @TheIntValue<> 1
                      BEGIN
                        RAISERROR(N'ERROR: Integer value for HasBonusFeature should be 1 but has value %d', 15, 1, @TheIntValue)
                        RETURN;
                      END;
                      ELSE 
                      BEGIN
                        PRINT N'OK: HasBonusFeature =1'
                      END;
                   END
    END
    IF (SELECT Count(*) FROM tb_GameSettings  WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'HasGambleFeature') = 0
    BEGIN
        RAISERROR(N'ERROR: GameSetting HasGambleFeature not found.', 15, 1);
        RETURN;
    END;
    ELSE 
    BEGIN
        SET @TheIntValue = NULL
        SET @TheStrValue = NULL
                SELECT @TheIntValue = IntValue, @TheStrValue = StrValue FROM tb_GameSettings WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'HasGambleFeature'
                  IF NOT @TheStrValue IS NULL
                   BEGIN
                      RAISERROR(N'ERROR: String value for HasGambleFeature should not be set but it has value %s', 15, 1, @TheStrValue)
                      RETURN
                   END;
                  ELSE 
                   BEGIN
                      IF @TheIntValue<> 0
                      BEGIN
                        RAISERROR(N'ERROR: Integer value for HasGambleFeature should be 0 but has value %d', 15, 1, @TheIntValue)
                        RETURN;
                      END;
                      ELSE 
                      BEGIN
                        PRINT N'OK: HasGambleFeature =0'
                      END;
                   END
    END
    IF (SELECT Count(*) FROM tb_GameSettings  WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'HasFreeSpinFeature') = 0
    BEGIN
        RAISERROR(N'ERROR: GameSetting HasFreeSpinFeature not found.', 15, 1);
        RETURN;
    END;
    ELSE 
    BEGIN
        SET @TheIntValue = NULL
        SET @TheStrValue = NULL
                SELECT @TheIntValue = IntValue, @TheStrValue = StrValue FROM tb_GameSettings WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'HasFreeSpinFeature'
                  IF NOT @TheStrValue IS NULL
                   BEGIN
                      RAISERROR(N'ERROR: String value for HasFreeSpinFeature should not be set but it has value %s', 15, 1, @TheStrValue)
                      RETURN
                   END;
                  ELSE 
                   BEGIN
                      IF @TheIntValue<> 1
                      BEGIN
                        RAISERROR(N'ERROR: Integer value for HasFreeSpinFeature should be 1 but has value %d', 15, 1, @TheIntValue)
                        RETURN;
                      END;
                      ELSE 
                      BEGIN
                        PRINT N'OK: HasFreeSpinFeature =1'
                      END;
                   END
    END
    IF (SELECT Count(*) FROM tb_GameSettings  WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'HasNudgeFeature') = 0
    BEGIN
        RAISERROR(N'ERROR: GameSetting HasNudgeFeature not found.', 15, 1);
        RETURN;
    END;
    ELSE 
    BEGIN
        SET @TheIntValue = NULL
        SET @TheStrValue = NULL
                SELECT @TheIntValue = IntValue, @TheStrValue = StrValue FROM tb_GameSettings WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'HasNudgeFeature'
                  IF NOT @TheStrValue IS NULL
                   BEGIN
                      RAISERROR(N'ERROR: String value for HasNudgeFeature should not be set but it has value %s', 15, 1, @TheStrValue)
                      RETURN
                   END;
                  ELSE 
                   BEGIN
                      IF @TheIntValue<> 0
                      BEGIN
                        RAISERROR(N'ERROR: Integer value for HasNudgeFeature should be 0 but has value %d', 15, 1, @TheIntValue)
                        RETURN;
                      END;
                      ELSE 
                      BEGIN
                        PRINT N'OK: HasNudgeFeature =0'
                      END;
                   END
    END
    IF (SELECT Count(*) FROM tb_GameSettings  WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'IsWayGame') = 0
    BEGIN
        RAISERROR(N'ERROR: GameSetting IsWayGame not found.', 15, 1);
        RETURN;
    END;
    ELSE 
    BEGIN
        SET @TheIntValue = NULL
        SET @TheStrValue = NULL
                SELECT @TheIntValue = IntValue, @TheStrValue = StrValue FROM tb_GameSettings WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'IsWayGame'
                  IF NOT @TheStrValue IS NULL
                   BEGIN
                      RAISERROR(N'ERROR: String value for IsWayGame should not be set but it has value %s', 15, 1, @TheStrValue)
                      RETURN
                   END;
                  ELSE 
                   BEGIN
                      IF @TheIntValue<> 0
                      BEGIN
                        RAISERROR(N'ERROR: Integer value for IsWayGame should be 0 but has value %d', 15, 1, @TheIntValue)
                        RETURN;
                      END;
                      ELSE 
                      BEGIN
                        PRINT N'OK: IsWayGame =0'
                      END;
                   END
    END
    IF (SELECT Count(*) FROM tb_GameSettings  WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'PaylineCountWithCost') = 0
    BEGIN
        RAISERROR(N'ERROR: GameSetting PaylineCountWithCost not found.', 15, 1);
        RETURN;
    END;
    ELSE 
    BEGIN
        SET @TheIntValue = NULL
        SET @TheStrValue = NULL
                SELECT @TheIntValue = IntValue, @TheStrValue = StrValue FROM tb_GameSettings WHERE ModuleID = 101421 AND ClientID = 40300 AND Name = 'PaylineCountWithCost'
                  IF NOT @TheStrValue IS NULL
                   BEGIN
                      RAISERROR(N'ERROR: String value for PaylineCountWithCost should not be set but it has value %s', 15, 1, @TheStrValue)
                      RETURN
                   END;
                  ELSE 
                   BEGIN
                      IF @TheIntValue<> 10
                      BEGIN
                        RAISERROR(N'ERROR: Integer value for PaylineCountWithCost should be 10 but has value %d', 15, 1, @TheIntValue)
                        RETURN;
                      END;
                      ELSE 
                      BEGIN
                        PRINT N'OK: PaylineCountWithCost =10'
                      END;
                   END
    END
--------------------------------------------------------------------------------------------
--End tb_GameSettings Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Default Module Setting Information Region
--------------------------------------------------------------------------------------------
    IF NOT EXISTS (SELECT 1 FROM tb_BetModel WHERE BetModelID = 64)
    BEGIN
        RAISERROR(N'ERROR: The Bet Model does not exist!', 15, 1);
        RETURN;
    END;
    IF((SELECT COUNT(*) FROM tb_BetModelSetting WHERE BetModelID = 64 AND SettingID in (105, 106, 214, 952, 955, 956, 948, 949, 950, 953)) != 10)
    BEGIN
        RAISERROR(N'ERROR: The Bet Model Setting does not exist!', 15, 1);
        RETURN;
    END;
    IF NOT EXISTS(SELECT 1 FROM tb_BetModelGame WHERE BetModelID = 64 and ModuleId =101421)
    BEGIN
        RAISERROR(N'ERROR: The Bet Model Game does not exists!', 15, 1);
        RETURN;
    END;
--------------------------------------------------------------------------------------------
--Install tb_SettingTemplate for 101421,40300,Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo
--------------------------------------------------------------------------------------------
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = 'Default Settings' AND TemplateID = 0
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:0 TemplateName:Default Settings', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = 'Low Settings' AND TemplateID = 1
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:1 TemplateName:Low Settings', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = 'High Settings' AND TemplateID = 2
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:2 TemplateName:High Settings', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '2 X Multiplier' AND TemplateID = 3
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:3 TemplateName:2 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '5 X Multiplier' AND TemplateID = 4
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:4 TemplateName:5 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '10 X Multiplier' AND TemplateID = 5
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:5 TemplateName:10 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '50 X Multiplier' AND TemplateID = 6
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:6 TemplateName:50 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '100 X Multiplier' AND TemplateID = 7
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:7 TemplateName:100 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '1000 X Multiplier' AND TemplateID = 8
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:8 TemplateName:1000 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '25 X Multiplier' AND TemplateID = 9
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:9 TemplateName:25 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '500 X Multiplier' AND TemplateID = 10
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:10 TemplateName:500 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = 'Bingo' AND TemplateID = 11
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:11 TemplateName:Bingo', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = 'Wide Settings' AND TemplateID = 12
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:12 TemplateName:Wide Settings', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '20 x Multiplier' AND TemplateID = 13
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:13 TemplateName:20 x Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '200 X Multiplier' AND TemplateID = 14
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:14 TemplateName:200 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '5000 X Multiplier' AND TemplateID = 15
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:15 TemplateName:5000 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '10000 X Multiplier' AND TemplateID = 16
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:16 TemplateName:10000 X Multiplier', 15, 1)
        RETURN;
    END;
    IF NOT EXISTS
    (
        SELECT 1 FROM tb_SettingTemplate WHERE TemplateName = '2000 X Multiplier' AND TemplateID = 17
    )
    BEGIN
        RAISERROR(N'ERROR: The Setting Template does not exists! Template ID:17 TemplateName:2000 X Multiplier', 15, 1)
        RETURN;
    END;
--------------------------------------------------------------------------------------------
--End tb_SettingTemplate Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Install tb_SettingTemplateValue for 101421, 40300, Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo
--------------------------------------------------------------------------------------------

DECLARE @IsLvcsEnabled BIT = 0;
IF EXISTS (SELECT 1 FROM tb_SystemSetting WHERE SystemSettingID = 87 AND SystemSettingIntValue = 1)
BEGIN
    SET @IsLvcsEnabled = 1;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 105
            AND SettingIntValue = 2500
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template Default Settings with value 2500 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 106
            AND SettingIntValue = 20
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template Default Settings with value 20 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 214
            AND SettingIntValue = 200
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template Default Settings with value 200 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 952
            AND SettingIntValue = 1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinCoinsPerLineOrWay for template Default Settings with value 1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 955
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxCoinsPerLineOrWay for template Default Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 956
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultCoinsPerLineOrWay for template Default Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 948
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBetMultiplier for template Default Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 949
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBetMultiplier for template Default Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 950
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBetMultiplier for template Default Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 0
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template Default Settings with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 105
            AND SettingIntValue = 2500
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template Low Settings with value 2500 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 106
            AND SettingIntValue = 20
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template Low Settings with value 20 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 214
            AND SettingIntValue = 200
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template Low Settings with value 200 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 952
            AND SettingIntValue = 1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinCoinsPerLineOrWay for template Low Settings with value 1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 955
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxCoinsPerLineOrWay for template Low Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 956
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultCoinsPerLineOrWay for template Low Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 948
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBetMultiplier for template Low Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 949
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBetMultiplier for template Low Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 950
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBetMultiplier for template Low Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 1
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template Low Settings with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 105
            AND SettingIntValue = 2500
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template High Settings with value 2500 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 106
            AND SettingIntValue = 20
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template High Settings with value 20 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 214
            AND SettingIntValue = 200
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template High Settings with value 200 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 952
            AND SettingIntValue = 1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinCoinsPerLineOrWay for template High Settings with value 1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 955
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxCoinsPerLineOrWay for template High Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 956
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultCoinsPerLineOrWay for template High Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 948
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBetMultiplier for template High Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 949
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBetMultiplier for template High Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 950
            AND SettingIntValue = 10
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBetMultiplier for template High Settings with value 10 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 2
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template High Settings with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 4
            AND SettingID = 105
            AND SettingIntValue = 10000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 5 X Multiplier with value 10000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 4
            AND SettingID = 106
            AND SettingIntValue = 100
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 5 X Multiplier with value 100 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 4
            AND SettingID = 214
            AND SettingIntValue = 1000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 5 X Multiplier with value 1000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 4
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 5 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 5
            AND SettingID = 105
            AND SettingIntValue = 20000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 10 X Multiplier with value 20000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 5
            AND SettingID = 106
            AND SettingIntValue = 200
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 10 X Multiplier with value 200 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 5
            AND SettingID = 214
            AND SettingIntValue = 2000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 10 X Multiplier with value 2000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 5
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 10 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 6
            AND SettingID = 105
            AND SettingIntValue = 100000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 50 X Multiplier with value 100000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 6
            AND SettingID = 106
            AND SettingIntValue = 1000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 50 X Multiplier with value 1000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 6
            AND SettingID = 214
            AND SettingIntValue = 10000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 50 X Multiplier with value 10000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 6
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 50 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 7
            AND SettingID = 106
            AND SettingIntValue = 2000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 100 X Multiplier with value 2000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 7
            AND SettingID = 214
            AND SettingIntValue = 20000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 100 X Multiplier with value 20000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 7
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 100 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 10
            AND SettingID = 106
            AND SettingIntValue = 10000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 500 X Multiplier with value 10000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 10
            AND SettingID = 214
            AND SettingIntValue = 100000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 500 X Multiplier with value 100000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 10
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 500 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 13
            AND SettingID = 105
            AND SettingIntValue = 50000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 20 x Multiplier with value 50000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 13
            AND SettingID = 106
            AND SettingIntValue = 250
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 20 x Multiplier with value 250 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 13
            AND SettingID = 214
            AND SettingIntValue = 2500
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 20 x Multiplier with value 2500 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 13
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 20 x Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 14
            AND SettingID = 106
            AND SettingIntValue = 2000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 200 X Multiplier with value 2000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 14
            AND SettingID = 214
            AND SettingIntValue = 20000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 200 X Multiplier with value 20000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 14
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 200 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

    IF @IsLvcsEnabled = 0
    BEGIN
IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 7
            AND SettingID = 105
            AND SettingIntValue = 200000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 100 X Multiplier with value 200000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 10
            AND SettingID = 105
            AND SettingIntValue = 200000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 500 X Multiplier with value 200000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 14
            AND SettingID = 105
            AND SettingIntValue = 200000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 200 X Multiplier with value 200000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

    END
    IF @IsLvcsEnabled = 1
    BEGIN
IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 7
            AND SettingID = 105
            AND SettingIntValue = 250000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 100 X Multiplier with value 250000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 8
            AND SettingID = 105
            AND SettingIntValue = 2000000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 1000 X Multiplier with value 2000000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 8
            AND SettingID = 106
            AND SettingIntValue = 20000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 1000 X Multiplier with value 20000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 8
            AND SettingID = 214
            AND SettingIntValue = 200000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 1000 X Multiplier with value 200000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 8
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 1000 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 10
            AND SettingID = 105
            AND SettingIntValue = 1000000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 500 X Multiplier with value 1000000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 14
            AND SettingID = 105
            AND SettingIntValue = 500000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 200 X Multiplier with value 500000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 15
            AND SettingID = 105
            AND SettingIntValue = 10000000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 5000 X Multiplier with value 10000000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 15
            AND SettingID = 106
            AND SettingIntValue = 100000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 5000 X Multiplier with value 100000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 15
            AND SettingID = 214
            AND SettingIntValue = 1000000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 5000 X Multiplier with value 1000000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 15
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 5000 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 16
            AND SettingID = 105
            AND SettingIntValue = 20000000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 10000 X Multiplier with value 20000000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 16
            AND SettingID = 106
            AND SettingIntValue = 200000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 10000 X Multiplier with value 200000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 16
            AND SettingID = 214
            AND SettingIntValue = 2000000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 10000 X Multiplier with value 2000000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 16
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 10000 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 17
            AND SettingID = 105
            AND SettingIntValue = 5000000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxBet for template 2000 X Multiplier with value 5000000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 17
            AND SettingID = 106
            AND SettingIntValue = 25000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MinBet for template 2000 X Multiplier with value 25000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 17
            AND SettingID = 214
            AND SettingIntValue = 250000
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting DefaultBet for template 2000 X Multiplier with value 250000 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

IF NOT EXISTS
(
    SELECT 1
    FROM tb_SettingTemplateValue
    WHERE ModuleID = 101421
            AND ClientID = 40300
            AND BetModelID = 64
            AND TemplateID = 17
            AND SettingID = 953
            AND SettingIntValue = -1
           AND SettingStringValue IS NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: The required Setting MaxPurchaseBet for template 2000 X Multiplier with value -1 does not exist!',
                 15,
                 1
             );
        RETURN;
    END;

    END
--------------------------------------------------------------------------------------------
--End tb_SettingTemplateValue Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Install tb_MGSDefaultModuleSetting for 101421, 40300, Slingshot - HTML5 - Slot - Candy Combo™ - Power Combo
--------------------------------------------------------------------------------------------
    IF NOT EXISTS(SELECT 1 FROM tb_MGSDefaultModuleSetting WHERE ModuleID = 101421 AND ClientID = 0 AND SettingID = 102 AND SettingIntValue = 100 AND SettingStringValue is NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: tb_MGSDefaultModuleSetting does not contain a row with a ModuleID of: 101421, ClientID of: 0, SettingID of: 102 and SettingIntValue of: 100 and SettingStringValue of:NULL',
                 15,
                 1
             );
        RETURN;
    END;
    ELSE 
    BEGIN
            PRINT N'OK: tb_MGSDefaultModuleSetting - ModuleID = 101421, ClientID = 0, SettingID = 102, SettingIntValue = 100, SettingStringValue = NULL'
    END;
    IF NOT EXISTS(SELECT 1 FROM tb_MGSDefaultModuleSetting WHERE ModuleID = 101421 AND ClientID = 40300 AND SettingID = 111 AND SettingIntValue = 1 AND SettingStringValue is NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: tb_MGSDefaultModuleSetting does not contain a row with a ModuleID of: 101421, ClientID of: 40300, SettingID of: 111 and SettingIntValue of: 1 and SettingStringValue of:NULL',
                 15,
                 1
             );
        RETURN;
    END;
    ELSE 
    BEGIN
            PRINT N'OK: tb_MGSDefaultModuleSetting - ModuleID = 101421, ClientID = 40300, SettingID = 111, SettingIntValue = 1, SettingStringValue = NULL'
    END;
    IF NOT EXISTS(SELECT 1 FROM tb_MGSDefaultModuleSetting WHERE ModuleID = 101421 AND ClientID = 0 AND SettingID = 158 AND SettingIntValue = 100 AND SettingStringValue is NULL)
    BEGIN
        RAISERROR(
                 N'ERROR: tb_MGSDefaultModuleSetting does not contain a row with a ModuleID of: 101421, ClientID of: 0, SettingID of: 158 and SettingIntValue of: 100 and SettingStringValue of:NULL',
                 15,
                 1
             );
        RETURN;
    END;
    ELSE 
    BEGIN
            PRINT N'OK: tb_MGSDefaultModuleSetting - ModuleID = 101421, ClientID = 0, SettingID = 158, SettingIntValue = 100, SettingStringValue = NULL'
    END;
--------------------------------------------------------------------------------------------
--End tb_MGSDefaultModuleSetting Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Default Module Setting Information Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Install tb_ThermometerInfo Setting  Region
--------------------------------------------------------------------------------------------
    IF NOT EXISTS(SELECT 1 FROM tb_ThermometerInfo WHERE ModuleID = 101421 AND ClientID = 40300  AND HeatConstant = 8000 AND BetMultiplier = 20)
    BEGIN
        RAISERROR(N'ERROR: tb_ThermometerInfo does not contain a row with a ModuleID of: 101421, ClientID of: 40300, HeatConstant of: 8000 and BetMultiplier of: 20', 15, 1)
        RETURN;
    END;
    ELSE
    BEGIN
        PRINT N'OK: tb_thermometerinfo - BetMultiplier = 20, HeatConstant = 8000'
    END;
--------------------------------------------------------------------------------------------
--End tb_ThermometerInfo Setting  Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Module Exclusion Information  Region
--------------------------------------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM tb_ExcludeModule WHERE ModuleID = 101421 )
    BEGIN
         RAISERROR(N'ERROR: tb_ExcludeModule contains a row for ModuleID 101421 but should not have one.', 16, -1)
         RETURN
    END;
    ELSE 
    BEGIN
         PRINT N'OK: Module not excluded.';
    END;
--------------------------------------------------------------------------------------------
--END Module Exclusion Information  Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Free Game Support Information Region
--------------------------------------------------------------------------------------------
    IF NOT EXISTS(SELECT 1 FROM tb_FreeGameSupportedClient WHERE ModuleID = 101421 AND ClientID = 40300 AND IsSupported = 1 AND IsBetSettingValidated = 0 )
    BEGIN
        RAISERROR(N'ERROR: tb_FreeGameSupportedClient does not contain a row with a ModuleID 101421 ClientID 40300 and IsSupported', 15, 1)
        RETURN;
    END;
    ELSE 
    BEGIN
        PRINT N'OK: FreeGames Supported';
    END;
--------------------------------------------------------------------------------------------
--Free Game Support Information End Region
--------------------------------------------------------------------------------------------
DECLARE @ChipSizes varchar(MAX)
	set @ChipSizes = '1,2,5,10,20,25,50,100,200,500,1000,2000,2500,5000,10000'
IF @IsLvcsEnabled = 1
BEGIN
	set @ChipSizes = '1,2,5,10,20,25,50,100,200,500,1000,2000,2500,5000,10000,20000,50000,100000,200000,500000,1000000,2000000,5000000,10000000,20000000,50000000'
END

--------------------------------------------------------------------------------------------
--Valid Bet Limit Information Region
--------------------------------------------------------------------------------------------
DECLARE @DBMaxNumPaylines INT = 0,
        @DBMaxNumCoins INT = 0,
        @DBSideBet INT = 0,
        @DBWayGamesBetMultiplier INT = 0,
        @DBChipSizes VARCHAR(2000) = 'N/A',
        @DBTieToPaylines INT = 0,
        @DBTieToCoinSize INT = 0,
        @DBTieToNumCoins INT = 0;

SELECT  @DBMaxNumPaylines = Paylines,
        @DBMaxNumCoins = Coins,
        @DBSideBet = SideBet,
        @DBWayGamesBetMultiplier = BetMultiplier,
        @DBChipSizes = ChipSizes,
        @DBTieToPaylines = SideBetToNumberLines,
        @DBTieToNumCoins = SideBetToNrcoins,
        @DBTieToCoinSize = SideBetToChipsize
FROM tb_Slot_ValidBetLimits
WHERE ModuleID = 101421;

    IF @DBMaxNumPaylines <> 20
    BEGIN
         PRINT N'WARNING : SlotBetLimits : MaxPaylines incorrect should be [20] currently '
                 + CAST(@DBMaxNumPaylines as varchar(10))
    END;
    ELSE
    BEGIN
         PRINT N'OK: MaxPaylines=20';
    END;

    IF @DBMaxNumCoins <> 10
    BEGIN
         PRINT N'WARNING : SlotBetLimits : MaxCoins incorrect should be [10] currently '
                + CAST(@DBMaxNumCoins as varchar(10));
    END;
    ELSE
    BEGIN
         PRINT N'OK: MaxCoins=10';
    END;

    IF @DBSideBet <> 0
    BEGIN
         PRINT N'WARNING : SlotBetLimits : SideBet incorrect should be [0] currently '
               + CAST(@DBSideBet as varchar(10));
    END;
    ELSE
    BEGIN
         PRINT N'OK: SideBet=0';
    END;

    IF @DBWayGamesBetMultiplier<> 0
    BEGIN
         PRINT N'WARNING : SlotBetLimits : WayGamesBetMultiplier incorrect should be [0] currently '
               + CAST(@DBWayGamesBetMultiplier as varchar(10));
    END;
    ELSE
    BEGIN
         PRINT N'OK: WayGamesBetMultiplier=0';
    END;

    IF NOT(@DBChipSizes = @ChipSizes)
    BEGIN
         PRINT N'WARNING : SlotBetLimits : ChipSize incorrect should be [@ChipSizes] currently '
               + COALESCE(@DBChipSizes, 'N/A');
    END;
    ELSE
    BEGIN
         PRINT N'OK: ChipSizes=@ChipSizes';
    END;

    IF @DBTieToCoinSize <> 0
    BEGIN
         PRINT N'WARNING : SlotBetLimits : SideBetToChipsize incorrect should be [0] currently ' + CAST(@DBTieToCoinSize as varchar(1))
    END;
    ELSE
    BEGIN
         PRINT N'OK: SideBetToChipsize=0';
    END;

    IF @DBTieToPaylines <> 0
    BEGIN
         PRINT N'WARNING : SlotBetLimits : SideBetToNumberLines incorrect should be [0] currently ' + CAST(@DBTieToPaylines as varchar(1))
    END;
    ELSE
    BEGIN
         PRINT N'OK: SideBetToNumberLines=0';
    END;
    if @DBTieToNumCoins <> 0
    BEGIN
         PRINT N'WARNING : SlotBetLimits : SideBetToNrcoins incorrect should be [0] currently ' + CAST(@DBTieToNumCoins as varchar(1))
    END;
    ELSE
    BEGIN
         PRINT N'OK: SideBetToNrcoins=0';
    END;
--------------------------------------------------------------------------------------------
--Valid Bet Limit Information End Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Extended Slot Module  Region
--------------------------------------------------------------------------------------------
     IF NOT EXISTS(SELECT 1 FROM Casino.tb_ExtendedSlotModuleSetting WHERE ModuleID = 101421)
     BEGIN
          RAISERROR(N'ERROR: Casino.tb_ExtendedSlotModuleSetting does not contain a row with a ModuleID of: 101421', 15, 1)
          RETURN
     END;
     ELSE 
     BEGIN
          PRINT N'OK: Casino.tb_ExtendedSlotModuleSetting ';
     END;
--------------------------------------------------------------------------------------------
--Extended Slot Module End  Region
--------------------------------------------------------------------------------------------
SET NOCOUNT OFF;
